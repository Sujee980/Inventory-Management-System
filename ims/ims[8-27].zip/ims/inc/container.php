</head>
<body class="bg-gradient bg-dark bg-opacity-25">
<nav role="navigation" class="navbar navbar-dark navbar-static-top bg-primary bg-gradient">
    <div class="container">
      <div class="navbar-header">
          <img src="IMG_9321.PNG" height="40" width="40">
        <a href="" class="navbar-brand"> Inventory Management System Department Of Physical Science</a>
      </div>
    </div>
  </nav>
	
	<div class="container">
	